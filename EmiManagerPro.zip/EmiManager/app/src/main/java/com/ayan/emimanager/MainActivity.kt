package com.ayan.emimanager

import android.Manifest
import android.content.Context
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
                .launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "due", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<DueWorker>(1, TimeUnit.DAYS).build())
        setContent { MaterialTheme { App(this) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(c: Context) {
    var list by remember { mutableStateOf(Store.load(c)) }
    var adding by remember { mutableStateOf(false) }
    var payFor by remember { mutableStateOf<Customer?>(null) }
    fun upd(l: List<Customer>) { list = l; Store.save(c, l) }
    Scaffold(
        topBar = { TopAppBar(title = { Text("EMI ম্যানেজার") }) },
        floatingActionButton = { FloatingActionButton(onClick = { adding = true }) { Text("+") } }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).padding(8.dp)) {
            item {
                Text("মোট বকেয়া: ৳${list.sumOf { it.overdue }} | মোট বাকি: ৳${list.sumOf { it.remaining }}",
                    fontWeight = FontWeight.Bold)
            }
            items(list) { x ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${x.name} (${x.phone})", fontWeight = FontWeight.Bold)
                        Text("${x.model} | মাসিক ৳${x.monthly} × ${x.months} মাস")
                        Text("জমা ৳${x.down + x.paid} | বাকি ৳${x.remaining}")
                        Text("বকেয়া ৳${x.overdue}", color = if (x.overdue > 0) Color.Red else Color(0xFF2E7D32))
                        Row {
                            Button(onClick = { payFor = x }) { Text("কিস্তি জমা") }
                            Spacer(Modifier.width(8.dp))
                            TextButton(onClick = { upd(list.filter { it.id != x.id }) }) { Text("মুছুন") }
                        }
                    }
                }
            }
        }
    }
    if (adding) AddDialog({ adding = false }) { upd(list + it); adding = false }
    payFor?.let { p ->
        AmountDialog(p.name, { payFor = null }) { amt ->
            upd(list.map { if (it.id == p.id) it.copy(paid = it.paid + amt) else it })
            payFor = null
        }
    }
}

@Composable
fun AddDialog(onDismiss: () -> Unit, onSave: (Customer) -> Unit) {
    val f = remember { mutableStateListOf("", "", "", "", "", "", "") }
    val labels = listOf("নাম", "ফোন নম্বর", "ফোনের মডেল", "ফোনের দাম", "ডাউন পেমেন্ট", "মাসিক কিস্তি", "কত মাস")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন ক্রেতা") },
        text = { LazyColumn { items(7) { i ->
            OutlinedTextField(f[i], { f[i] = it }, label = { Text(labels[i]) }, singleLine = true)
        } } },
        confirmButton = { Button(onClick = {
            if (f[0].isNotBlank()) onSave(Customer(System.currentTimeMillis(), f[0], f[1], f[2],
                f[3].toLongOrNull() ?: 0L, f[4].toLongOrNull() ?: 0L, f[5].toLongOrNull() ?: 0L,
                f[6].toIntOrNull() ?: 1, System.currentTimeMillis(), 0L))
        }) { Text("সংরক্ষণ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
fun AmountDialog(name: String, onDismiss: () -> Unit, onOk: (Long) -> Unit) {
    var t by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("$name - কিস্তি জমা") },
        text = { OutlinedTextField(t, { t = it }, label = { Text("টাকা") }, singleLine = true) },
        confirmButton = { Button(onClick = { t.toLongOrNull()?.let(onOk) }) { Text("জমা") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}
