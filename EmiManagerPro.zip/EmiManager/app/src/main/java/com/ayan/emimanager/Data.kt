package com.ayan.emimanager

import android.app.*
import android.content.Context
import androidx.work.*
import org.json.JSONArray
import org.json.JSONObject

data class Customer(
    val id: Long, val name: String, val phone: String, val model: String,
    val price: Long, val down: Long, val monthly: Long, val months: Int,
    val start: Long, val paid: Long
) {
    val remaining: Long get() = price - down - paid
    val overdue: Long get() {
        val d = (System.currentTimeMillis() - start) / (30L * 24 * 3600 * 1000)
        val due = minOf(months.toLong(), maxOf(0L, d))
        return maxOf(0L, due * monthly - paid)
    }
}

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("emi", Context.MODE_PRIVATE)
    fun load(c: Context): List<Customer> {
        val a = JSONArray(sp(c).getString("d", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Customer(o.getLong("id"), o.getString("name"), o.getString("phone"), o.getString("model"),
                o.getLong("price"), o.getLong("down"), o.getLong("monthly"), o.getInt("months"),
                o.getLong("start"), o.getLong("paid"))
        }
    }
    fun save(c: Context, l: List<Customer>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("phone", it.phone)
                .put("model", it.model).put("price", it.price).put("down", it.down)
                .put("monthly", it.monthly).put("months", it.months).put("start", it.start)
                .put("paid", it.paid))
        }
        sp(c).edit().putString("d", a.toString()).apply()
    }
}

class DueWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        val late = Store.load(applicationContext).filter { it.overdue > 0 }
        if (late.isNotEmpty()) {
            val nm = applicationContext.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("due", "Kisti", NotificationManager.IMPORTANCE_DEFAULT))
            val n = Notification.Builder(applicationContext, "due")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("বকেয়া কিস্তি")
                .setContentText("${late.size} জনের কিস্তি বকেয়া আছে").build()
            nm.notify(1, n)
        }
        return Result.success()
    }
}
